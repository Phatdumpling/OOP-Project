//Part of menu package
package menu;

public class Prime extends Operator{
  //I needed a method to override and this is the method, if you noticed its the same one from OOP part 1
  public void AQ() {
    System.out.println("[WIP] come back later");
    System.out.println("No longer WIP gave up may be put in the next challenge");
  }
}