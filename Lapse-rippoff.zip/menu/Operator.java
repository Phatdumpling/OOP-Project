//Part of menu package
package menu;

public class Operator {
  //I thought this would be a useful tool since I forget how to terminate java programs so I just make a method for it
  protected void terminate() {
    System.exit(0);
  }
}